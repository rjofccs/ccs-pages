import enMessages from './en';

export const en = enMessages;
