package com.example.myproject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import com.alibaba.fastjson.JSON;
import java.util.*;
import java.io.File;

@Controller
@RequestMapping("/")
public class WebController {
	private static final Logger logger =  LoggerFactory.getLogger(WebController.class);

	public static String toTitleCase(String input) {
        StringBuilder titleCase = new StringBuilder(input.length());
        boolean nextTitleCase = true;
        for (char c : input.toCharArray()) {
            if (Character.isSpaceChar(c)) {
                nextTitleCase = true;
            } else if (nextTitleCase) {
                c = Character.toTitleCase(c);
                nextTitleCase = false;
            }
            titleCase.append(c);
        }
        return titleCase.toString();
    }

	@RequestMapping("")
	public String index(ModelMap modelMap){
        List<Map> list = new LinkedList<>();
		File dir = new File("/mp3");
		if (dir.isDirectory()) {
            String[] children = dir.list();
            for (int i = 0; i < children.length; i++) {
                String fn = children[i];
                if(fn.endsWith(".mp3")){
                    Map<String, String> res = new HashMap<>();
                    res.put("src", "./mp3/"+fn);
                    String fname = fn.substring(0, fn.length() - 4);
                    res.put("lyric", "./mp3/"+fname+".lrc");
                    res.put("title", toTitleCase(fname.replace('-', ' ')));
                    list.add(res);
                }
            }
        }
		String json = JSON.toJSONString(list);
		logger.info(json);
        modelMap.addAttribute("mp3json", json);
		return "index.html";
	}

}